let client = require('../dbConnection');

let collection = client.db("CoffeeDB").collection('CoffeeCollection');

function addCoffee(coffeenames, callback) {
    collection.insertOne(coffeenames, callback);
}

function getAllCoffee(callback) {
    collection.find({}).toArray(callback);
}

module.exports = { addCoffee, getAllCoffee }