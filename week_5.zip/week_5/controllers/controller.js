let collection = require('../models/coffee');

const addCoffee = (req, res) => {
    let data = req.body;
    collection.addCoffee(data, (err, result) => {
        if (!err) {
            res.json({ statusCode: 201, data: result, message: 'success' });
        }
    });
}

const getAllCoffee = (req, res) => {
    collection.getAllCoffee((error, result) => {
        if (!error) {
            res.json({ statusCode: 200, data: result, message: 'success' });
        }
    });
}

module.exports = { addCoffee, getAllCoffee }